import React, { useEffect, useMemo, useState } from "react";
import type { LicenseRiskTier, ScanSbomResponse } from "../../types/phase6a";

interface ScanSbomTabProps {
  projectId: string | number;
  scanId: string | number;
}

const TIER_BADGE_STYLES: Record<
  LicenseRiskTier,
  { label: string; bg: string; border: string; color: string }
> = {
  permissive: {
    label: "Permissive",
    bg: "rgba(16, 185, 129, 0.15)",
    border: "rgba(52, 211, 153, 0.4)",
    color: "#6ee7b7",
  },
  weak_copyleft: {
    label: "Weak Copyleft",
    bg: "rgba(245, 158, 11, 0.16)",
    border: "rgba(251, 191, 36, 0.45)",
    color: "#fcd34d",
  },
  restricted_copyleft: {
    label: "Restricted Copyleft · Violation",
    bg: "rgba(220, 38, 38, 0.22)",
    border: "rgba(248, 113, 113, 0.55)",
    color: "#fca5a5",
  },
  unknown: {
    label: "Unknown / Unmapped",
    bg: "rgba(100, 116, 139, 0.2)",
    border: "rgba(148, 163, 184, 0.35)",
    color: "#cbd5e1",
  },
};

export const ScanSbomTab: React.FC<ScanSbomTabProps> = ({
  projectId,
  scanId,
}) => {
  const [sbom, setSbom] = useState<ScanSbomResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [tierFilter, setTierFilter] = useState<string>("all");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetch(`/workspace/projects/${projectId}/scans/${scanId}/sbom`, {
      credentials: "include",
    })
      .then(async (res) => {
        if (!res.ok) {
          const errBody = await res.json().catch(() => ({}));
          throw new Error(errBody.detail || `Failed to load SBOM (${res.status})`);
        }
        return res.json() as Promise<ScanSbomResponse>;
      })
      .then((data) => {
        if (!cancelled) {
          setSbom(data);
        }
      })
      .catch((err: Error) => {
        if (!cancelled) {
          setError(err.message);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [projectId, scanId]);

  const filteredComponents = useMemo(() => {
    if (!sbom) return [];
    const q = searchQuery.trim().toLowerCase();
    return sbom.components.filter((comp) => {
      if (tierFilter !== "all" && comp.risk_tier !== tierFilter) {
        return false;
      }
      if (!q) return true;
      return (
        comp.name.toLowerCase().includes(q) ||
        comp.version.toLowerCase().includes(q) ||
        comp.purl.toLowerCase().includes(q) ||
        comp.licenses.some((lic) => lic.toLowerCase().includes(q))
      );
    });
  }, [sbom, searchQuery, tierFilter]);

  const handleDownloadCycloneDx = () => {
    window.location.href = `/workspace/projects/${projectId}/scans/${scanId}/sbom/download`;
  };

  if (loading) {
    return (
      <div
        style={{
          padding: "32px",
          textAlign: "center",
          color: "#94a3b8",
          backgroundColor: "var(--bg-primary, #0a0e17)",
          border: "1px solid var(--border-subtle, #1e293b)",
          borderRadius: "12px",
        }}
      >
        Loading CycloneDX 1.5 Software Bill of Materials...
      </div>
    );
  }

  if (error || !sbom) {
    return (
      <div
        style={{
          padding: "24px",
          color: "#fca5a5",
          backgroundColor: "rgba(127, 29, 29, 0.2)",
          border: "1px solid rgba(248, 113, 113, 0.4)",
          borderRadius: "12px",
        }}
      >
        {error || "No SBOM artifact available for this scan."}
      </div>
    );
  }

  const summaryCards = [
    {
      title: "Total Components",
      value: sbom.component_count,
      subtitle: sbom.spec_version,
      accent: "#3b82f6",
    },
    {
      title: "Permissive",
      value: sbom.license_summary.permissive ?? 0,
      subtitle: "MIT, Apache-2.0, BSD, ISC",
      accent: "#10b981",
    },
    {
      title: "Weak Copyleft",
      value: sbom.license_summary.weak_copyleft ?? 0,
      subtitle: "LGPL, MPL-2.0, EPL",
      accent: "#f59e0b",
    },
    {
      title: "Restricted / Policy Violations",
      value: sbom.policy_violations_count,
      subtitle: "GPL, AGPL, SSPL",
      accent: sbom.policy_violations_count > 0 ? "#ef4444" : "#64748b",
    },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
      {/* 1. Four Summary Cards */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: "14px",
        }}
      >
        {summaryCards.map((card) => (
          <div
            key={card.title}
            style={{
              padding: "16px 18px",
              borderRadius: "12px",
              backgroundColor: "rgba(15, 23, 42, 0.78)",
              border: "1px solid var(--border-subtle, #1e293b)",
              borderTop: `3px solid ${card.accent}`,
            }}
          >
            <div style={{ fontSize: "0.78rem", color: "#94a3b8" }}>
              {card.title}
            </div>
            <div
              style={{
                fontSize: "1.65rem",
                fontWeight: 700,
                color: "#f8fafc",
                margin: "6px 0 4px",
              }}
            >
              {card.value}
            </div>
            <div style={{ fontSize: "0.72rem", color: "#64748b" }}>
              {card.subtitle}
            </div>
          </div>
        ))}
      </div>

      {/* 2. Search, Filter & Download Bar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: "12px",
          padding: "12px 16px",
          borderRadius: "10px",
          backgroundColor: "rgba(15, 23, 42, 0.75)",
          border: "1px solid var(--border-subtle, #1e293b)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            flex: "1 1 320px",
          }}
        >
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by package name, PURL, or SPDX license (e.g. AGPL-3.0, MIT)..."
            style={{
              flex: 1,
              padding: "8px 12px",
              borderRadius: "8px",
              backgroundColor: "var(--bg-primary, #0a0e17)",
              border: "1px solid var(--border-subtle, #1e293b)",
              color: "#f8fafc",
              fontSize: "0.84rem",
            }}
          />

          <select
            value={tierFilter}
            onChange={(e) => setTierFilter(e.target.value)}
            style={{
              padding: "8px 12px",
              borderRadius: "8px",
              backgroundColor: "var(--bg-primary, #0a0e17)",
              border: "1px solid var(--border-subtle, #1e293b)",
              color: "#e2e8f0",
              fontSize: "0.84rem",
            }}
          >
            <option value="all">All Policy Tiers</option>
            <option value="restricted_copyleft">Restricted Copyleft</option>
            <option value="weak_copyleft">Weak Copyleft</option>
            <option value="permissive">Permissive</option>
            <option value="unknown">Unknown</option>
          </select>
        </div>

        <button
          type="button"
          onClick={handleDownloadCycloneDx}
          style={{
            padding: "8px 16px",
            borderRadius: "8px",
            backgroundColor: "var(--accent-primary, #3b82f6)",
            border: "none",
            color: "#ffffff",
            fontWeight: 600,
            fontSize: "0.84rem",
            cursor: "pointer",
          }}
        >
          Download CycloneDX (.cdx.json)
        </button>
      </div>

      {/* 3. Component Table */}
      <div
        style={{
          overflowX: "auto",
          borderRadius: "12px",
          border: "1px solid var(--border-subtle, #1e293b)",
          backgroundColor: "rgba(15, 23, 42, 0.72)",
        }}
      >
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            textAlign: "left",
            fontSize: "0.84rem",
            color: "#e2e8f0",
          }}
        >
          <thead>
            <tr
              style={{
                borderBottom: "1px solid var(--border-subtle, #1e293b)",
                backgroundColor: "rgba(30, 41, 59, 0.55)",
                color: "#94a3b8",
                fontSize: "0.75rem",
                textTransform: "uppercase",
                letterSpacing: "0.04em",
              }}
            >
              <th style={{ padding: "12px 16px" }}>Package</th>
              <th style={{ padding: "12px 16px" }}>Version</th>
              <th style={{ padding: "12px 16px" }}>Ecosystem / PURL</th>
              <th style={{ padding: "12px 16px" }}>License</th>
              <th style={{ padding: "12px 16px" }}>Policy Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredComponents.length === 0 ? (
              <tr>
                <td
                  colSpan={5}
                  style={{
                    padding: "24px",
                    textAlign: "center",
                    color: "#64748b",
                  }}
                >
                  No components match the current filter.
                </td>
              </tr>
            ) : (
              filteredComponents.map((comp) => {
                const badge =
                  TIER_BADGE_STYLES[comp.risk_tier] || TIER_BADGE_STYLES.unknown;
                return (
                  <tr
                    key={comp.purl}
                    style={{
                      borderBottom: "1px solid rgba(30, 41, 59, 0.65)",
                    }}
                  >
                    <td style={{ padding: "11px 16px", fontWeight: 600 }}>
                      {comp.name}
                    </td>
                    <td
                      style={{
                        padding: "11px 16px",
                        fontFamily: "monospace",
                        color: "#93c5fd",
                      }}
                    >
                      {comp.version}
                    </td>
                    <td
                      style={{
                        padding: "11px 16px",
                        fontFamily: "monospace",
                        fontSize: "0.76rem",
                        color: "#94a3b8",
                      }}
                    >
                      {comp.purl}
                    </td>
                    <td
                      style={{
                        padding: "11px 16px",
                        fontFamily: "monospace",
                        fontSize: "0.78rem",
                      }}
                    >
                      {comp.licenses.join(", ")}
                    </td>
                    <td style={{ padding: "11px 16px" }}>
                      <span
                        style={{
                          display: "inline-block",
                          padding: "3px 9px",
                          borderRadius: "999px",
                          fontSize: "0.72rem",
                          fontWeight: 600,
                          backgroundColor: badge.bg,
                          border: `1px solid ${badge.border}`,
                          color: badge.color,
                        }}
                      >
                        {badge.label}
                      </span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
